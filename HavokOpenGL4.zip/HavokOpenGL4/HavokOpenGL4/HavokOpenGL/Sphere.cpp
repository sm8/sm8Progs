#include "Sphere.h"
#define _USE_MATH_DEFINES	//for constants in math.h
#include <math.h>

Sphere::Sphere(void) : HavokObj(){
	radius = 0.1f;
}

void Sphere::init(hkpWorld* m_world){
	hkpSphereShape* sphere = new hkpSphereShape(radius);		// Create a sphere
	// convex radius for spheres is exactly the sphere radius
	float m = density * 4.0f * HK_REAL_PI * radius * radius * radius / 3.0f;
	this->setRigidBodyInfo(m_world, sphere, m);
	//hkpRigidBodyCinfo rigidBodyInfo;
	//rigidBodyInfo.m_shape = sphere;
	//rigidBodyInfo.m_motionType = hkpMotion::MOTION_DYNAMIC;
	//hkpInertiaTensorComputer::setShapeVolumeMassProperties(sphere, 1.0f, rigidBodyInfo);
	//rigidBodyInfo.m_position.set(1.0, 1.2, 0.0);
	//rigidBodyInfo.m_friction = 0.4f;
	//rigidBodyInfo.m_restitution = 0.2f;

	//rb = new hkpRigidBody(rigidBodyInfo);
	//sphere->removeReference();
	//m_world->addEntity(rb);
	//rb->removeReference();
}

Sphere::~Sphere(void){
}
