#pragma once

#include "havokobj.h"

class Sphere :	public HavokObj{
protected:
	//float radius;
public:
	Sphere(void);
	~Sphere(void);

	void init(hkpWorld* m_world);

	//void setRadius(float r){ radius = r; }
	//float getRadius(){ return radius; }
};

