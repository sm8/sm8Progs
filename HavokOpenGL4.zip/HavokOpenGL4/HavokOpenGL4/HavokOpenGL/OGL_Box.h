#pragma once

#include "hvkoglobj.h"
#include "Box.h"

class OGL_Box :	public HvkOGLObj{
	Vector verts[8];
public:
	OGL_Box(Box* hvkBox);
	OGL_Box(Box* hvkBox, char *img);
	~OGL_Box(void);

	void render();
	void setSize(float sx,float sy, float sz);
private:
	void drawFace(int v0, int v1, int v2, int v3, float r, float g, float b);
	void drawFace(int v0, int v1, int v2, int v3, float r, float g, float b, bool rep);
};

