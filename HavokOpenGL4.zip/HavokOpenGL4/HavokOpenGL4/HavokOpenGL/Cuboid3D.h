#pragma once

#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <cmath>
#include <math.h>

#include "vector.h"

#define M_PI       3.14159265358979323846
const double DTR = M_PI/180;

class Cuboid3D{
private:
	float s;

	Vector verts[8];

	/// Coordinates of the centre of the cube
	Vector pos;
	/// Velocity of the cube
	Vector vel;
public:
	/**
	Creates a cube of size 0.2
	*/
	Cuboid3D(void);

	/**
	Creates a cube of the given size
	*/
	Cuboid3D(float size);
	Cuboid3D(float sx, float sy, float sz);

	~Cuboid3D(void);

	/**
	Sets the position of the cube centre
	*/
	void setPos(float x, float y, float z);

	Vector getPos() { return pos; };
	/**
	Sets the cubes velocity in 3D space
	*/
	void setVel(float x, float y, float z);

	/**
	Move the cube by (velocity * time)
	@param time elapsed time in seconds
	*/
	void Move(float time);

	/**
	Update the cube's state based on elpased time
	@param time elapsed time in seconds
	*/
	void Update(float time);

	/**
	Draw the cube
	*/
	void Render();

	/**
	Set / change the size of the cube <br>
	Calculates and store the vertex data for a cube based on a given
	size. 
	*/
	void setSize(float size);
private:
	/**
	Used internally by the render method to render a single face
	*/
	void drawFace(int v0, int v1, int v2, int v3, float r, float g, float b);

};
