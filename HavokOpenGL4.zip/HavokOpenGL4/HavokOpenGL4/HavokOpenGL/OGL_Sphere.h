#pragma once

#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include "hvkoglobj.h"
#include "Sphere.h"

class OGL_Sphere :	public HvkOGLObj{
	GLUquadricObj *oglQuad;
public:
	OGL_Sphere(Sphere *sph);
	OGL_Sphere(Sphere *sph, char *img);
	~OGL_Sphere(void);

	void render();
};

