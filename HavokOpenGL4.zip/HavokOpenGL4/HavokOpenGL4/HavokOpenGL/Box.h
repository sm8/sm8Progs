#pragma once

#include "HavokObj.h"

class Box :	public HavokObj{
	float sx, sy, sz;
public:
	Box(float sx = 0.2f, float sy = 0.2f, float sz = 0.2f);	//default at 0.2f cube
	~Box(void);
	void init(hkpWorld *world);

	float getSx(){ return sx; }
	float getSy(){ return sy; }
	float getSz(){ return sz; }
};

