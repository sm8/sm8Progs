#pragma once

#include "HavokInit.h"	//for Havok
#include "Vector.h"	
#include "DebugPrint.h"	

/*
  Abstract Base Class for storing a Havok Rigid body object
*/
class HavokObj{
protected:
	hkpRigidBody* rb;	//****
	hkpRigidBodyCinfo rigidBodyInfo;
	Vector pos, dir;
	float density;
	float radius;	//****
public:
	HavokObj();
	virtual ~HavokObj();

	virtual void init(hkpWorld *world) = 0;	//initialise specific Hvk body rb and attach to world
	void setRigidBodyInfo(hkpWorld *world, hkpShape *hks, float mass);

//	void update();
	Vector getPos(){ return pos; }
	void setPos(Vector p){ pos = p; /*char s[50]; sprintf(s, "x=%.1f y=%.1f z=%.1f", pos.x, pos.y, pos.z); DebugOut(s);*/ }
	void setDir(Vector d){ dir = d; }
	Vector getDir(){ return dir; }
	hkpRigidBody* getRigidBody() { return rb; }
	void setDensity(float d){ density = d; }
	void setRadius(float r){ radius = r; }
	float getRadius(){ return radius; }
};