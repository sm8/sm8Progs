#include "Cuboid3D.h"

Cuboid3D::Cuboid3D(void){
	setSize(0.2f);
}

Cuboid3D::Cuboid3D(float size){
	setSize(size);
}

Cuboid3D::Cuboid3D(float sx, float sy, float sz){
	sx /= 2; sy /= 2; sz /= 2; 
	verts[0].set(-sx, sy, sz);
	verts[1].set( sx, sy, sz);
	verts[2].set( sx, sy,-sz);
	verts[3].set(-sx, sy,-sz);
	verts[4].set(-sx,-sy, sz);
	verts[5].set( sx,-sy, sz);
	verts[6].set( sx,-sy,-sz);
	verts[7].set(-sx,-sy,-sz);
}

Cuboid3D::~Cuboid3D(void){
}

void Cuboid3D::setPos(float x, float y, float z){
	pos.x = x;
	pos.y = y;
	pos.z = z;
}

void Cuboid3D::setVel(float x, float y, float z){
	vel.x = x;
	vel.y = y;
	vel.z = z;
}

void Cuboid3D::Move(float time){
	pos.x += vel.x * time;
	pos.y += vel.y * time;
	pos.z += vel.z * time;
}

void Cuboid3D::Update(float time){
	Move(time);
}

void Cuboid3D::Render(){
	glPushMatrix();
		// Perform transformations here in TRS order
	glTranslatef(pos.x, pos.y, pos.z);

		// Draw each face with a different colour
		drawFace(0, 4, 5, 1, 0.5f, 0.5f, 1.0f);
		drawFace(3, 7, 4, 0, 0.5f, 1.0f, 0.5f);
		drawFace(2, 6, 7, 3, 0.5f, 1.0f, 1.0f);
		drawFace(1, 5, 6, 2, 1.0f, 0.5f, 0.5f);
		drawFace(3, 0, 1, 2, 1.0f, 0.5f, 1.0f);
		drawFace(4, 7, 6, 5, 1.0f, 1.0f, 0.5f);
	glPopMatrix();
}

void Cuboid3D::drawFace(int v0, int v1, int v2, int v3, float r, float g, float b){
	glColor3f(r, g, b);
	glBegin(GL_QUADS);
		glVertex3f(verts[v0].x, verts[v0].y, verts[v0].z);
		glVertex3f(verts[v1].x, verts[v1].y, verts[v1].z);
		glVertex3f(verts[v2].x, verts[v2].y, verts[v2].z);
		glVertex3f(verts[v3].x, verts[v3].y, verts[v3].z);
	glEnd();
}


void Cuboid3D::setSize(float size){
	s = (float) size;
	float hs = size / 2;
	verts[0].set(-hs, hs, hs);
	verts[1].set( hs, hs, hs);
	verts[2].set( hs, hs,-hs);
	verts[3].set(-hs, hs,-hs);
	verts[4].set(-hs,-hs, hs);
	verts[5].set( hs,-hs, hs);
	verts[6].set( hs,-hs,-hs);
	verts[7].set(-hs,-hs,-hs);
}

